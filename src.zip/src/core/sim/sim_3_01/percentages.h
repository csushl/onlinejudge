/*	This file is part of the software similarity tester SIM.
	Written by Dick Grune, Vrije Universiteit, Amsterdam.
	$Id: percentages.h,v 1.6 2016-07-31 18:55:44 dick Exp $
*/

extern void add_to_percentages(
    const struct text *txt0, const struct text *txt1, size_t size);
extern void Show_Percentages(void);
